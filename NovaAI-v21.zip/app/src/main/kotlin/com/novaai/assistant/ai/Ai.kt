package com.novaai.assistant.ai

import android.content.Context
import android.util.Base64
import com.novaai.assistant.assist.IntentRouter
import com.novaai.assistant.assist.Routed
import com.novaai.assistant.control.CmdJson
import com.novaai.assistant.control.DeviceActions
import com.novaai.assistant.control.Executor
import com.novaai.assistant.data.Repo
import com.novaai.assistant.data.Store
import com.novaai.assistant.voice.Tts
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

class NoKeyException : Exception("NO_KEY")

object LlmClient {
    private const val SYSTEM =
        "You are Nova, a warm, concise voice assistant. Reply in the same language the user writes " +
            "(Bangla, English or mixed). Keep replies short and natural to be spoken aloud. No markdown. " +
            "You can also control the user's phone. When the user asks you to DO something on the phone, " +
            "reply with ONLY one JSON object and nothing else, for example {\"action\":\"call\",\"who\":\"Rahim\"}. " +
            "Actions: open_app(name), call(who), sms(who,text), whatsapp(who,text), next, previous, " +
            "auto_scroll(seconds), stop_scroll, back, home, recents, notifications, tap(text), type(text), like, " +
            "volume(dir=up|down|mute), media(kind=play|pause|next|prev), torch(on=true|false), wifi, bluetooth, time. " +
            "For normal conversation answer in plain text, never JSON. " +
            "You were created by NAFIS. If anyone asks who made, created or built you, answer that NAFIS made you. Support and updates are on the Telegram channel @mdnafis568."

    fun provider(): String? = when {
        Store.str("k_groq").isNotBlank() -> "groq"
        Store.str("k_gemini").isNotBlank() -> "gemini"
        Store.str("k_openai").isNotBlank() -> "openai"
        else -> null
    }

    private fun model(p: String): String = Store.str("m_$p").ifBlank {
        when (p) {
            "gemini" -> "gemini-flash-latest"
            "groq" -> "llama-3.3-70b-versatile"
            else -> "gpt-4o-mini"
        }
    }

    /** history: (fromUser, text) pairs, newest last. */
    suspend fun chat(history: List<Pair<Boolean, String>>): String = withContext(Dispatchers.IO) {
        val p = provider() ?: throw NoKeyException()
        val mem = Store.str("memory")
        val persona = Store.str("persona", "Friendly")
        val sys = SYSTEM + "\nYour personality: $persona." + if (mem.isBlank()) "" else "\nWhat you know about the user: $mem"
        val msgs = history.dropWhile { !it.first }

        withKeys(p) { key ->
        if (p == "gemini") {
            val contents = JSONArray()
            msgs.forEach { (u, t) ->
                contents.put(
                    JSONObject().put("role", if (u) "user" else "model")
                        .put("parts", JSONArray().put(JSONObject().put("text", t)))
                )
            }
            val body = JSONObject()
                .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", sys))))
                .put("contents", contents).toString()
            val res = post(
                "https://generativelanguage.googleapis.com/v1beta/models/${model(p)}:generateContent",
                mapOf("x-goog-api-key" to key), body
            )
            val parts = JSONObject(res).getJSONArray("candidates").getJSONObject(0)
                .getJSONObject("content").getJSONArray("parts")
            buildString { for (i in 0 until parts.length()) append(parts.getJSONObject(i).optString("text")) }.trim()
        } else {
            val arr = JSONArray().put(JSONObject().put("role", "system").put("content", sys))
            msgs.forEach { (u, t) -> arr.put(JSONObject().put("role", if (u) "user" else "assistant").put("content", t)) }
            val url = if (p == "groq") "https://api.groq.com/openai/v1/chat/completions"
            else "https://api.openai.com/v1/chat/completions"
            val body = JSONObject().put("model", model(p)).put("messages", arr).toString()
            val res = post(url, mapOf("Authorization" to "Bearer $key"), body)
            JSONObject(res).getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content").trim()
        }
        }
    }

    @Volatile private var rot = 0

    /** Tries each comma-separated key in turn, so one rate-limited key doesn't stop Nova. */
    private fun <T> withKeys(p: String, block: (String) -> T): T {
        val keys = Store.str("k_$p").split(',').map { it.trim() }.filter { it.isNotEmpty() }
        if (keys.isEmpty()) throw NoKeyException()
        var last: Exception? = null
        for (i in keys.indices) {
            val k = keys[(rot + i) % keys.size]
            try {
                val r = block(k)
                rot = (rot + i) % keys.size
                return r
            } catch (e: Exception) { last = e }
        }
        rot = (rot + 1) % keys.size
        throw last ?: NoKeyException()
    }

    private fun post(url: String, headers: Map<String, String>, body: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.connectTimeout = 15000
            c.readTimeout = 60000
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
            c.outputStream.use { it.write(body.toByteArray()) }
            val code = c.responseCode
            val text = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() } ?: ""
            if (code !in 200..299) {
                val msg = runCatching { JSONObject(text).getJSONObject("error").getString("message") }.getOrDefault("HTTP $code")
                throw IOException(msg)
            }
            return text
        } finally {
            c.disconnect()
        }
    }

    /** Turns a WAV clip into text with your own key (Gemini first, then Groq / OpenAI Whisper). */
    fun transcribe(wav: ByteArray): String {
        val gem = Store.str("k_gemini").trim()
        if (gem.isNotEmpty()) {
            val prompt = "Transcribe this speech exactly as spoken. Write Bangla in Bengali script and English in English. " +
                "Output only the transcription. If there is no clear human speech, output nothing."
            val parts = JSONArray()
                .put(JSONObject().put("text", prompt))
                .put(JSONObject().put("inlineData", JSONObject().put("mimeType", "audio/wav").put("data", Base64.encodeToString(wav, Base64.NO_WRAP))))
            val body = JSONObject().put("contents", JSONArray().put(JSONObject().put("parts", parts))).toString()
            val res = post("https://generativelanguage.googleapis.com/v1beta/models/${model("gemini")}:generateContent",
                mapOf("x-goog-api-key" to gem), body)
            return runCatching {
                val ps = JSONObject(res).getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts")
                buildString { for (i in 0 until ps.length()) append(ps.getJSONObject(i).optString("text")) }.trim()
            }.getOrDefault("")
        }
        val groq = Store.str("k_groq").split(',').first().trim()
        val oai = Store.str("k_openai").trim()
        return when {
            groq.isNotEmpty() -> multipart("https://api.groq.com/openai/v1/audio/transcriptions", groq, "whisper-large-v3-turbo", wav)
            oai.isNotEmpty() -> multipart("https://api.openai.com/v1/audio/transcriptions", oai, "whisper-1", wav)
            else -> throw NoKeyException()
        }
    }

    private fun multipart(url: String, key: String, model: String, wav: ByteArray): String {
        val b = "----nova" + System.currentTimeMillis()
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"; c.connectTimeout = 15000; c.readTimeout = 60000; c.doOutput = true
            c.setRequestProperty("Authorization", "Bearer " + key)
            c.setRequestProperty("Content-Type", "multipart/form-data; boundary=" + b)
            c.outputStream.use { o ->
                fun field(n: String, v: String) {
                    o.write(("--" + b + "\r\nContent-Disposition: form-data; name=\"" + n + "\"\r\n\r\n" + v + "\r\n").toByteArray())
                }
                field("model", model); field("response_format", "text")
                field("language", Store.str("lang", "bn-BD").take(2))
                o.write(("--" + b + "\r\nContent-Disposition: form-data; name=\"file\"; filename=\"a.wav\"\r\nContent-Type: audio/wav\r\n\r\n").toByteArray())
                o.write(wav)
                o.write(("\r\n--" + b + "--\r\n").toByteArray())
            }
            val code = c.responseCode
            val text = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() } ?: ""
            if (code !in 200..299) throw IOException("HTTP " + code)
            return text.trim()
        } finally {
            c.disconnect()
        }
    }

    /** Finds the newest Gemini model on your key that supports live voice (no hard-coded model name). */
    fun liveModel(): String? {
        Store.str("m_live").takeIf { it.isNotBlank() }?.let { return it }
        val key = Store.str("k_gemini").trim()
        if (key.isEmpty()) return null
        val c = URL("https://generativelanguage.googleapis.com/v1beta/models?pageSize=200").openConnection() as HttpURLConnection
        return try {
            c.setRequestProperty("x-goog-api-key", key); c.connectTimeout = 10000; c.readTimeout = 15000
            if (c.responseCode !in 200..299) null else {
                val arr = JSONObject(c.inputStream.bufferedReader().use { it.readText() }).getJSONArray("models")
                val names = ArrayList<String>()
                for (i in 0 until arr.length()) {
                    val m = arr.getJSONObject(i)
                    val ms = m.optJSONArray("supportedGenerationMethods") ?: continue
                    for (j in 0 until ms.length()) if (ms.getString(j) == "bidiGenerateContent") { names.add(m.getString("name")); break }
                }
                val pool = names.filter { it.contains("native-audio") }.ifEmpty { names.filter { it.contains("live") } }.ifEmpty { names }
                pool.sortedDescending().firstOrNull()
            }
        } catch (e: Exception) { null } finally { c.disconnect() }
    }

    /** ElevenLabs voice as raw 24 kHz 16-bit mono PCM. */
    fun elevenPcm(text: String): ByteArray {
        val key = Store.str("k_eleven").trim()
        val voice = Store.str("el_voice").ifBlank { "21m00Tcm4TlvDq8ikWAM" }
        val c = URL("https://api.elevenlabs.io/v1/text-to-speech/" + voice + "?output_format=pcm_24000").openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"; c.connectTimeout = 15000; c.readTimeout = 60000; c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            c.setRequestProperty("xi-api-key", key)
            c.outputStream.use { it.write(JSONObject().put("text", text).put("model_id", "eleven_multilingual_v2").toString().toByteArray()) }
            if (c.responseCode !in 200..299) throw IOException("HTTP " + c.responseCode)
            return c.inputStream.use { it.readBytes() }
        } finally {
            c.disconnect()
        }
    }

    /** Natural voice from Gemini (raw 24 kHz 16-bit mono PCM). Throws if it isn't available. */
    fun speechPcm(text: String): ByteArray {
        val key = Store.str("k_gemini").trim()
        val cfg = JSONObject().put("responseModalities", JSONArray().put("AUDIO")).put("speechConfig",
            JSONObject().put("voiceConfig", JSONObject().put("prebuiltVoiceConfig", JSONObject().put("voiceName", Store.str("voice", "Kore")))))
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", text)))))
            .put("generationConfig", cfg).toString()
        val m = Store.str("m_tts").ifBlank { "gemini-3.1-flash-tts-preview" }
        val res = post("https://generativelanguage.googleapis.com/v1beta/models/" + m + ":generateContent", mapOf("x-goog-api-key" to key), body)
        val data = JSONObject(res).getJSONArray("candidates").getJSONObject(0).getJSONObject("content")
            .getJSONArray("parts").getJSONObject(0).getJSONObject("inlineData").getString("data")
        return Base64.decode(data, Base64.DEFAULT)
    }

    fun imageUrl(prompt: String) =
        "https://image.pollinations.ai/prompt/" + URLEncoder.encode(prompt, "UTF-8") + "?width=768&height=768&nologo=true"
}

data class Reply(val text: String, val close: Boolean = false, val spoken: Boolean = false)

/** One path for typed chat, in-app voice, the floating orb and the always-on mic. */
object ChatEngine {
    /**
     * speak = true means voice mode: quiet commands (scroll, back, like...) are not logged or spoken,
     * and the answer is read aloud; onSpoken runs when the speech ends.
     */
    suspend fun send(ctx: Context, text: String, speak: Boolean = false, onSpoken: (() -> Unit)? = null): Reply {
        val app = ctx.applicationContext
        val r = try {
            IntentRouter.route(app, text)
        } catch (e: Exception) {
            Routed(true, "That didn't work: ${e.message ?: "unknown error"}")
        }
        if (r.handled && r.quiet && speak) return Reply(r.reply, r.close)
        if (!r.handled && r.searchQuery == null && speak && LlmClient.provider() == null) return Reply("") // not a phone command: stay silent

        Repo.addUser(text)
        Repo.busy.value = true
        var ok = true
        val out: String = try {
            when {
                r.searchQuery != null -> {
                    DeviceActions.webSearch(app, r.searchQuery)
                    "গুগলে সার্চ করছি, ${Store.name} ভাই"
                }
                r.handled -> r.reply
                else -> {
                    if (LlmClient.provider() == null) "আমি শুধু ফোন চালাতে পারি। বলো: টিকটক ওপেন করো, রহিমকে কল করো, পরের ভিডিও, ভলিউম বাড়াও"
                    else {
                        val hist = Repo.messages.value.filter { it.imageUrl == null }.takeLast(12).map { it.fromUser to it.text }
                        val answer = LlmClient.chat(hist)
                        val cmd = CmdJson.tryParse(answer)
                        if (cmd != null) Executor.run(app, cmd).reply else answer
                    }
                }
            }
        } catch (e: NoKeyException) {
            ok = false
            "Add an AI key first: Settings → Connections. Free Gemini key: aistudio.google.com/apikey"
        } catch (e: Exception) {
            ok = false
            "Couldn't get an answer: ${e.message ?: "unknown error"}"
        }
        Repo.addAssistant(out)
        Repo.busy.value = false
        val spoken = speak && ok
        if (spoken) Tts.speak(app, out, onSpoken)
        return Reply(out, r.close, spoken)
    }

    fun image(prompt: String) {
        Repo.addUser("🖼️ $prompt")
        Repo.addAssistant("", LlmClient.imageUrl(prompt))
    }
}
