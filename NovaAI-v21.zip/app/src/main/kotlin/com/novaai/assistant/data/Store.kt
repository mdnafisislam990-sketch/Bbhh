package com.novaai.assistant.data

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate

object Store {
    private lateinit var sp: SharedPreferences
    val hey = MutableStateFlow(false)
    val notif = MutableStateFlow(false)

    fun init(ctx: Context) {
        sp = ctx.applicationContext.getSharedPreferences("nova", Context.MODE_PRIVATE)
        hey.value = bool("hey")
        notif.value = bool("notif")
    }

    fun str(k: String, d: String = ""): String = sp.getString(k, d) ?: d
    fun put(k: String, v: String) = sp.edit().putString(k, v).apply()
    fun bool(k: String, d: Boolean = false) = sp.getBoolean(k, d)
    fun putBool(k: String, v: Boolean) = sp.edit().putBoolean(k, v).apply()

    fun setHey(b: Boolean) { putBool("hey", b); hey.value = b }
    fun setNotif(b: Boolean) { putBool("notif", b); notif.value = b }

    var name: String
        get() = str("name", "নাফিজ")
        set(v) = put("name", v)

    fun clearAll() {
        sp.edit().clear().apply()
        hey.value = false
        notif.value = false
    }

    fun streak(): Int {
        val today = LocalDate.now().toString()
        val last = str("streak_last")
        var n = str("streak_n", "0").toIntOrNull() ?: 0
        if (last != today) {
            n = if (last == LocalDate.now().minusDays(1).toString()) n + 1 else 1
            put("streak_last", today)
            put("streak_n", n.toString())
        }
        return n
    }

    fun moodToday(): Int =
        if (str("mood_date") == LocalDate.now().toString()) str("mood_i", "-1").toIntOrNull() ?: -1 else -1

    fun setMood(i: Int) { put("mood_date", LocalDate.now().toString()); put("mood_i", i.toString()) }

    fun appendDiary(text: String) {
        val k = "diary_" + LocalDate.now()
        put(k, (str(k) + "\n" + text).trim())
    }
}

data class ChatMessage(val text: String, val fromUser: Boolean, val imageUrl: String? = null, val time: Long = System.currentTimeMillis())
data class HistoryItem(val title: String, val time: Long)

object Repo {
    val messages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val history = MutableStateFlow<List<HistoryItem>>(emptyList())
    val tasks = MutableStateFlow<List<String>>(emptyList())
    val busy = MutableStateFlow(false)

    fun load() {
        messages.value = runCatching {
            val a = JSONArray(Store.str("chat", "[]"))
            (0 until a.length()).map {
                val o = a.getJSONObject(it)
                ChatMessage(o.getString("t"), o.getBoolean("u"), o.optString("i").ifBlank { null }, o.optLong("d"))
            }
        }.getOrDefault(emptyList())
        history.value = runCatching {
            val a = JSONArray(Store.str("hist", "[]"))
            (0 until a.length()).map { val o = a.getJSONObject(it); HistoryItem(o.getString("t"), o.getLong("d")) }
        }.getOrDefault(emptyList())
        tasks.value = runCatching {
            val a = JSONArray(Store.str("tasks", "[]"))
            (0 until a.length()).map { a.getString(it) }
        }.getOrDefault(emptyList())
    }

    private fun saveChat() {
        val a = JSONArray()
        messages.value.takeLast(100).forEach {
            a.put(JSONObject().put("t", it.text).put("u", it.fromUser).put("i", it.imageUrl ?: "").put("d", it.time))
        }
        Store.put("chat", a.toString())
    }

    private fun saveHist() {
        val a = JSONArray()
        history.value.take(200).forEach { a.put(JSONObject().put("t", it.title).put("d", it.time)) }
        Store.put("hist", a.toString())
    }

    private fun saveTasks() {
        val a = JSONArray(); tasks.value.forEach { a.put(it) }
        Store.put("tasks", a.toString())
    }

    fun addUser(text: String) {
        messages.value = messages.value + ChatMessage(text, true)
        history.value = listOf(HistoryItem(text, System.currentTimeMillis())) + history.value
        saveChat(); saveHist()
    }

    fun addAssistant(text: String, imageUrl: String? = null) {
        messages.value = messages.value + ChatMessage(text, false, imageUrl)
        saveChat()
    }

    fun newChat() { messages.value = emptyList(); saveChat() }
    fun clearHistory() { history.value = emptyList(); saveHist() }
    fun addTask(t: String) { tasks.value = tasks.value + t; saveTasks() }
    fun doneTask(i: Int) { tasks.value = tasks.value.filterIndexed { idx, _ -> idx != i }; saveTasks() }

    fun exportJson(): String =
        JSONObject().put("chat", Store.str("chat", "[]")).put("history", Store.str("hist", "[]"))
            .put("tasks", Store.str("tasks", "[]")).put("memory", Store.str("memory")).toString(2)
}
