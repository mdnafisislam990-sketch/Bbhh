package com.novaai.assistant.control

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.novaai.assistant.R
import com.novaai.assistant.assist.Session
import java.io.ByteArrayOutputStream

/**
 * Real screen recording (MediaProjection). While it runs, [latest] always holds the newest picture of the
 * screen as a small JPEG, so Nova sees the phone like a live video with no screenshot limits.
 * Android asks the person for permission every time it starts.
 */
class ScreenCaptureService : Service() {
    private var proj: MediaProjection? = null
    private var vd: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var thread: HandlerThread? = null
    private var handler: Handler? = null
    private var lastConv = 0L
    private var scheduled = false

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        if (i?.action == ACTION_STOP) { Session.setScreenShare(false); stopSelf(); return START_NOT_STICKY }
        val code = i?.getIntExtra("code", 0) ?: 0
        @Suppress("DEPRECATION")
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33) i?.getParcelableExtra("data", Intent::class.java) else i?.getParcelableExtra("data")
        if (data == null || !goForeground()) { Session.setScreenShare(false); stopSelf(); return START_NOT_STICKY }
        if (!begin(code, data)) { Session.setScreenShare(false); stopSelf() }
        return START_NOT_STICKY
    }

    private fun goForeground(): Boolean {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "Nova screen share", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(
            this, 3, Intent(this, ScreenCaptureService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n: Notification = NotificationCompat.Builder(this, CH)
            .setSmallIcon(R.drawable.ic_stat_nova)
            .setContentTitle("Nova can see your screen")
            .setContentText("Tap Stop to stop sharing")
            .setOngoing(true)
            .addAction(R.drawable.ic_stat_nova, "Stop", stop)
            .build()
        return try {
            if (Build.VERSION.SDK_INT >= 29) startForeground(ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
            else startForeground(ID, n)
            true
        } catch (e: Exception) { false }
    }

    private fun begin(code: Int, data: Intent): Boolean {
        return try {
            val t = HandlerThread("nova-screen").also { it.start() }
            thread = t
            val h = Handler(t.looper)
            handler = h
            val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val p = mpm.getMediaProjection(code, data) ?: return false
            proj = p
            // Android 14+ requires a callback before the virtual display is created.
            p.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { Session.setScreenShare(false); stopSelf() }
            }, h)

            val dm = resources.displayMetrics
            val cw = 640
            val ch = ((dm.heightPixels.toLong() * cw / dm.widthPixels.coerceAtLeast(1)).toInt() / 2) * 2
            val r = ImageReader.newInstance(cw, ch, PixelFormat.RGBA_8888, 2)
            reader = r
            r.setOnImageAvailableListener({ onFrame() }, h)
            vd = p.createVirtualDisplay("nova-screen", cw, ch, dm.densityDpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, h)
            active = true
            true
        } catch (e: Exception) { false }
    }

    /** Called on every new screen frame. Converts at most ~3 times a second, and never loses the final frame. */
    private fun onFrame() {
        val now = System.currentTimeMillis()
        val wait = 330 - (now - lastConv)
        if (wait <= 0) convert()
        else if (!scheduled) { scheduled = true; handler?.postDelayed({ scheduled = false; convert() }, wait) }
    }

    private fun convert() {
        val r = reader ?: return
        val img = try { r.acquireLatestImage() } catch (e: Exception) { null } ?: return
        try {
            lastConv = System.currentTimeMillis()
            val pl = img.planes[0]
            val rowPx = pl.rowStride / pl.pixelStride
            val bmp = Bitmap.createBitmap(rowPx, img.height, Bitmap.Config.ARGB_8888)
            bmp.copyPixelsFromBuffer(pl.buffer)
            val crop = if (rowPx != img.width) Bitmap.createBitmap(bmp, 0, 0, img.width, img.height) else bmp
            val out = ByteArrayOutputStream()
            crop.compress(Bitmap.CompressFormat.JPEG, 62, out)
            latest = out.toByteArray()
            if (crop !== bmp) crop.recycle()
            bmp.recycle()
        } catch (e: Exception) {
        } finally {
            runCatching { img.close() }
        }
    }

    override fun onDestroy() {
        active = false
        latest = null
        runCatching { vd?.release() }
        runCatching { reader?.setOnImageAvailableListener(null, null); reader?.close() }
        runCatching { proj?.stop() }
        runCatching { thread?.quitSafely() }
        super.onDestroy()
    }

    companion object {
        private const val CH = "nova_screen"
        private const val ID = 2005
        const val ACTION_STOP = "nova.STOP_SCREEN"
        @Volatile var active = false
        @Volatile var latest: ByteArray? = null

        fun start(ctx: Context, code: Int, data: Intent) {
            runCatching {
                ctx.startForegroundService(Intent(ctx, ScreenCaptureService::class.java).putExtra("code", code).putExtra("data", data))
            }
        }

        fun stop(ctx: Context) { runCatching { ctx.stopService(Intent(ctx, ScreenCaptureService::class.java)) } }
    }
}
