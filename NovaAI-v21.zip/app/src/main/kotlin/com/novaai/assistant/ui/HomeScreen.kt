package com.novaai.assistant.ui

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.novaai.assistant.ai.ChatEngine
import com.novaai.assistant.assist.Session
import com.novaai.assistant.control.DeviceActions
import com.novaai.assistant.data.Repo
import com.novaai.assistant.data.Store
import com.novaai.assistant.utils.toast
import kotlinx.coroutines.launch
import java.time.LocalDate
import kotlin.random.Random

private val words = listOf(
    listOf("Practice", "অনুশীলন", "Practice makes perfect.", "অনুশীলনই পারদর্শিতা আনে।"),
    listOf("Gratitude", "কৃতজ্ঞতা", "Gratitude turns what we have into enough.", "যা আছে তাতেই তৃপ্তি আনে কৃতজ্ঞতা।"),
    listOf("Resilient", "স্থিতিস্থাপক", "She stayed resilient through hard times.", "কঠিন সময়ে সে দৃঢ় ছিল।"),
    listOf("Curious", "কৌতূহলী", "Stay curious and keep learning.", "কৌতূহলী থাকো, শিখতে থাকো।"),
    listOf("Courage", "সাহস", "Courage is taking the first step.", "প্রথম পদক্ষেপ নেওয়াই সাহস।")
)
private val moodFaces = listOf("😞", "😕", "😐", "🙂", "😄")
private val moodText = listOf(
    "মন খারাপ? আমি আছি, একটু বিশ্রাম নাও।", "কঠিন দিন, ধীরে ধীরে এগোও।", "ঠিক আছে, আজ ছোট একটা ভালো কাজ করো।",
    "ভালো লাগছে শুনে! এভাবেই চলুক।", "দারুণ! আজকের দিনটা উপভোগ করো 😊"
)

@Composable
fun HomeScreen(onNav: (String) -> Unit, onTalk: () -> Unit, listening: Boolean, onAsk: (String) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val tasks by Repo.tasks.collectAsState()
    var dialog by remember { mutableStateOf<String?>(null) }
    val streak = remember { Store.streak() }
    var mood by remember { mutableIntStateOf(Store.moodToday()) }
    val word = remember { words[LocalDate.now().dayOfMonth % words.size] }
    val name = Store.name
    val hearing by Session.hearing.collectAsState()
    val speaking by Session.speaking.collectAsState()
    val busy by Session.busy.collectAsState()
    val info by Session.info.collectAsState()
    var ask by remember { mutableStateOf("") }
    val amp = when { speaking -> 0.9f; hearing -> 1f; busy -> 0.6f; listening -> 0.4f; else -> 0.15f }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TopBtn("☰") { onNav("history") }
            Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("NOVA AI", fontSize = 30.sp, fontWeight = FontWeight.Bold)
                Text("YOUR AI ASSISTANT", fontSize = 10.sp, color = NovaColors.TextDim, letterSpacing = 3.sp)
            }
            TopBtn("⚙️") { onNav("settings") }
        }

        Box(Modifier.fillMaxWidth().height(250.dp), contentAlignment = Alignment.Center) {
            MatrixOrb(size = 190.dp, listening = listening || hearing, onClick = onTalk)
            Text("Hi,\nI'm\nNova ♡", Modifier.align(Alignment.TopStart).padding(top = 20.dp, start = 6.dp),
                fontFamily = FontFamily.Cursive, fontStyle = FontStyle.Italic, fontSize = 26.sp, color = NovaColors.Pink)
            Text("Always\nhere\nfor you ♡", Modifier.align(Alignment.TopEnd).padding(top = 20.dp, end = 6.dp),
                fontFamily = FontFamily.Cursive, fontStyle = FontStyle.Italic, fontSize = 22.sp, color = NovaColors.Cyan)
        }

        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            TalkButton(on = listening, onClick = onTalk)
            Spacer(Modifier.height(6.dp))
            Text(
                when { !listening -> "Tap to Talk"; busy -> "Thinking…"; speaking -> "Nova is speaking…"; hearing -> "Listening…"; else -> "Mic is ON" },
                fontSize = 22.sp, fontWeight = FontWeight.SemiBold
            )
            Text(
                if (info.isNotBlank()) info else if (listening) "Stays on until you tap the button again" else "Tap once to turn on. Tap again to turn off.",
                color = NovaColors.TextDim, fontSize = 12.sp
            )
        }

        Spacer(Modifier.height(16.dp))
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(30.dp)).background(NovaColors.Card)
                .border(1.dp, NovaColors.Line, RoundedCornerShape(30.dp)).padding(start = 16.dp, end = 6.dp, top = 6.dp, bottom = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("✨", fontSize = 18.sp)
            Spacer(Modifier.width(10.dp))
            BasicTextField(
                value = ask, onValueChange = { ask = it }, singleLine = true,
                textStyle = TextStyle(color = Color.White, fontSize = 16.sp), cursorBrush = SolidColor(Color.White),
                modifier = Modifier.weight(1f),
                decorationBox = { inner -> Box { if (ask.isEmpty()) Text("Ask me anything…", color = NovaColors.TextDim, fontSize = 16.sp); inner() } }
            )
            Box(
                Modifier.size(46.dp).clip(RoundedCornerShape(18.dp)).background(NovaGrad)
                    .clickable { val q = ask.trim(); if (q.isNotEmpty()) { ask = ""; onAsk(q) } },
                contentAlignment = Alignment.Center
            ) { Text("➤", fontSize = 18.sp) }
        }

        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            BigCard("💬", "Chat", "Get instant answers", Modifier.weight(1f)) { onNav("chat") }
            BigCard("🖼️", "Create Image", "Photos into sketches", Modifier.weight(1f)) { dialog = "image" }
            BigCard("📝", "Write", "Notes, code, content", Modifier.weight(1f)) { dialog = "write" }
        }

        Spacer(Modifier.height(14.dp))
        Text("Quick actions", fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(8.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            QA("💬", "Chat with Nova") { onNav("chat") }
            QA("⏰", "Set Alarm") { dialog = "alarm" }
            QA("▶️", "Open YouTube") { DeviceActions.openYouTube(ctx) }
            QA("📍", "Open Maps") { DeviceActions.openMaps(ctx) }
            QA("🖼️", "Image Generate") { dialog = "image" }
            QA("📰", "Daily summary") { onAsk("Give me a short daily summary: one motivating thought, one tip and one thing to do today. Reply in Bangla.") }
            QA("🔔", "Reminder") { dialog = "reminder" }
            QA("📔", "My Diary") { dialog = "diary" }
            QA("🎯", "Focus") { DeviceActions.setTimer(ctx, 1500, "Focus"); ctx.toast("Focus timer: 25 minutes") }
        }

        Spacer(Modifier.height(14.dp))
        NovaCard(Modifier.fillMaxWidth()) {
            Column {
                Text("Today Tasks", fontWeight = FontWeight.SemiBold)
                if (tasks.isEmpty()) Text("Nothing yet. Ask Nova to remind you and it will show up here.", color = NovaColors.TextDim, fontSize = 12.sp)
                tasks.forEachIndexed { i, t ->
                    Row(Modifier.fillMaxWidth().clickable { Repo.doneTask(i) }.padding(vertical = 6.dp)) {
                        Text("☐  ", fontSize = 16.sp); Text(t, fontSize = 14.sp)
                    }
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        NovaCard(Modifier.fillMaxWidth(), onClick = { onAsk("Give me one gratitude idea for today. Reply in Bangla, 2 short lines.") }) {
            Column {
                Text("Daily challenge ⭐ $streak", fontWeight = FontWeight.SemiBold)
                Text("✅ Ask Nova for a gratitude idea for today", color = NovaColors.TextDim, fontSize = 13.sp)
            }
        }
        Spacer(Modifier.height(12.dp))
        NovaCard(Modifier.fillMaxWidth()) {
            Column {
                Text("Word of the day 🔥 $streak", fontWeight = FontWeight.SemiBold)
                Text("📖 ${word[0]} = ${word[1]}", color = NovaColors.Cyan)
                Text("\"${word[2]}\"", color = NovaColors.TextDim, fontSize = 12.sp)
                Text("💡 ${word[3]}", color = NovaColors.TextDim, fontSize = 12.sp)
            }
        }
        Spacer(Modifier.height(12.dp))
        NovaCard(Modifier.fillMaxWidth()) {
            Column {
                Text("How are you today?", fontWeight = FontWeight.SemiBold)
                Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                    moodFaces.forEachIndexed { i, e ->
                        Text(e, fontSize = 28.sp, modifier = Modifier.clip(CircleShape)
                            .background(if (mood == i) NovaColors.Cyan.copy(alpha = .3f) else Color.Transparent)
                            .clickable { mood = i; Store.setMood(i) }.padding(6.dp))
                    }
                }
                if (mood >= 0) Text(moodText[mood], color = NovaColors.Cyan, fontSize = 13.sp)
            }
        }
        Spacer(Modifier.height(16.dp))
    }

    dialog?.let { kind ->
        val (title, hint) = when (kind) {
            "alarm" -> "Set alarm" to "e.g. 7:30 am"
            "reminder" -> "Reminder" to "Remind me to…"
            "diary" -> "My Diary" to "Write about your day"
            "write" -> "Write" to "What should I write?"
            else -> "Image Generate" to "Describe the image"
        }
        PromptDialog(title, hint, onDismiss = { dialog = null }) { text ->
            dialog = null
            when (kind) {
                "alarm" -> ctx.toast(DeviceActions.setAlarmFromText(ctx, text))
                "reminder" -> { Repo.addTask(text); ctx.toast("Reminder added") }
                "diary" -> { Store.appendDiary(text); ctx.toast("Diary saved") }
                "write" -> onAsk("Write this for me: $text")
                else -> { onNav("chat"); scope.launch { ChatEngine.image(text) } }
            }
        }
    }
}

@Composable
private fun TopBtn(icon: String, onClick: () -> Unit) {
    Box(
        Modifier.size(44.dp).clip(RoundedCornerShape(14.dp)).background(NovaColors.Card)
            .border(1.dp, NovaColors.Line, RoundedCornerShape(14.dp)).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Text(icon, fontSize = 18.sp) }
}

@Composable
private fun BigCard(icon: String, title: String, sub: String, modifier: Modifier, onClick: () -> Unit) {
    NovaCard(modifier.height(112.dp), onClick = onClick) {
        Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Text(icon, fontSize = 24.sp)
            Text(title, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
            Text(sub, color = NovaColors.TextDim, fontSize = 10.sp, lineHeight = 12.sp, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
        }
    }
}

/** Big mic button: tap = ON (stays on), tap again = OFF. Glows while on. */
@Composable
private fun TalkButton(on: Boolean, onClick: () -> Unit) {
    val t = rememberInfiniteTransition(label = "talk")
    val ring by t.animateFloat(0f, 1f, infiniteRepeatable(tween(1500, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "r")
    val glow = if (on) 0.35f + 0.4f * ring else 0.2f
    Box(
        Modifier.size(150.dp).clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Box(Modifier.size(150.dp).drawBehind {
            drawCircle(Brush.radialGradient(listOf(NovaColors.Purple.copy(alpha = glow), Color.Transparent)))
        })
        Box(
            Modifier.size(112.dp).clip(CircleShape).background(Color(0xFF120E30))
                .border(4.dp, Brush.sweepGradient(listOf(NovaColors.Cyan, NovaColors.Pink, NovaColors.Purple, NovaColors.Cyan)), CircleShape),
            contentAlignment = Alignment.Center
        ) { Text(if (on) "⏹" else "🎙️", fontSize = 38.sp) }
    }
}

@Composable
private fun QA(icon: String, label: String, onClick: () -> Unit) {
    NovaCard(Modifier.width(104.dp).height(78.dp), onClick = onClick) {
        Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Text(icon, fontSize = 22.sp)
            Text(label, fontSize = 11.sp)
        }
    }
}

/** Glowing orb with falling Matrix-style characters. */
@Composable
fun MatrixOrb(size: Dp = 190.dp, listening: Boolean = false, onClick: () -> Unit) {
    val cols = 14
    val t = rememberInfiniteTransition(label = "m")
    val ticker by t.animateFloat(0f, 1f, infiniteRepeatable(tween(3500, easing = LinearEasing)), label = "tick")
    val glow by t.animateFloat(0.45f, 1f, infiniteRepeatable(tween(1600), RepeatMode.Reverse), label = "glow")
    val speeds = remember { List(cols) { 0.5f + Random.nextFloat() } }
    val offs = remember { List(cols) { Random.nextFloat() } }
    val glyphs = remember { "01アイウエオ789ABCDEF/<>|5".toList() }
    val paint = remember {
        android.graphics.Paint().apply { isAntiAlias = true; typeface = android.graphics.Typeface.MONOSPACE }
    }
    val g = if (listening) 1f else glow

    Box(
        Modifier.size(size + 50.dp).clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Box(Modifier.size(size + 50.dp).drawBehind {
            drawCircle(Brush.radialGradient(listOf(NovaColors.Purple.copy(alpha = .40f * g), NovaColors.Cyan.copy(alpha = .12f * g), Color.Transparent)))
        })
        Canvas(
            Modifier.size(size).clip(CircleShape).background(Color(0xFF02080F))
                .border(2.dp, NovaColors.Green.copy(alpha = if (listening) 1f else .6f), CircleShape)
        ) {
            val w = this.size.width
            val h = this.size.height
            paint.textSize = w / 11f
            val colW = w / cols
            drawIntoCanvas { c ->
                for (i in 0 until cols) {
                    val head = ((ticker * speeds[i] + offs[i]) % 1f) * (h + paint.textSize * 9)
                    for (k in 0 until 9) {
                        val y = head - k * paint.textSize
                        if (y < 0f || y > h + paint.textSize) continue
                        val a = (1f - k / 9f).coerceIn(0f, 1f)
                        paint.color = (if (k == 0) Color(0xFFD8FFF4) else NovaColors.Green).copy(alpha = a).toArgb()
                        c.nativeCanvas.drawText(glyphs[(i * 7 + k + (ticker * 30).toInt()) % glyphs.size].toString(), i * colW + 2f, y, paint)
                    }
                }
            }
        }
    }
}
