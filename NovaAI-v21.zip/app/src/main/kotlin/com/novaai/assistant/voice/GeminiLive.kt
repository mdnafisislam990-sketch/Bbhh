package com.novaai.assistant.voice

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Handler
import android.os.Looper
import android.util.Base64
import com.novaai.assistant.ai.LlmClient
import com.novaai.assistant.assist.IntentRouter
import com.novaai.assistant.assist.Session
import com.novaai.assistant.control.NovaAccessibilityService
import com.novaai.assistant.control.ScreenCaptureService
import com.novaai.assistant.data.Store
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit

/**
 * Real-time voice conversation with Gemini Live: your voice streams up, the voice streams back,
 * and phone actions run through the "phone" tool. This is what makes it feel like a call.
 */
class GeminiLive(
    private val ctx: Context,
    private val onHearing: (Boolean) -> Unit,
    private val onSpeaking: (Boolean) -> Unit,
    private val onBusy: (Boolean) -> Unit,
    private val onUnavailable: () -> Unit,
    private val onFatal: (String) -> Unit
) {
    private val main = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val http = OkHttpClient.Builder().readTimeout(0, TimeUnit.MILLISECONDS).pingInterval(20, TimeUnit.SECONDS).build()
    @Volatile private var running = false
    @Volatile private var paused = false
    @Volatile private var ready = false
    @Volatile private var everReady = false
    @Volatile private var gaveUp = false
    @Volatile private var reconnecting = false
    @Volatile private var gen = 0
    @Volatile private var readyAt = 0L
    @Volatile private var quick = 0
    @Volatile private var lastWhy = ""
    @Volatile private var ws: WebSocket? = null
    @Volatile private var track: AudioTrack? = null
    @Volatile private var playUntil = 0L
    private var tries = 0
    // Unbounded on purpose: Gemini sends speech faster than real time, and dropping chunks makes the voice skip. Interrupts clear it.
    private val q = LinkedBlockingQueue<ByteArray>()
    @Volatile private var trackEnd = 0L
    @Volatile private var flushGen = 0
    private var pcmBytes = ByteArray(0)
    private var sm: SteadyMic? = null
    private var lastSp = false
    private var player: Thread? = null
    private var lastShotHash = 0
    private var newUtterance = true
    private var frames = 0
    private var lastShotAt = 0L
    private var shareJob: kotlinx.coroutines.Job? = null

    fun start() {
        if (running) return
        running = true; paused = false
        Session.info.value = "Connecting to Gemini Live…"
        startPlayer(); startMic(); connect(); startScreenShare()
    }

    fun pause() { paused = true; sm?.muted = true; onHearing(false) }
    fun resume() { if (running) { paused = false; sm?.muted = false } }

    fun stop() {
        running = false; ready = false; gen++
        runCatching { ws?.close(1000, "bye") }; ws = null
        sm?.stop(); sm = null
        player?.interrupt(); q.clear()
        runCatching { track?.stop() }; runCatching { track?.release() }; track = null
        shareJob?.cancel(); scope.cancel()
        Session.heard.value = ""
        onHearing(false); onSpeaking(false); onBusy(false)
    }

    private fun connect() {
        Thread {
            val model = LlmClient.liveModel()
            if (model == null) { if (everReady) { reconnecting = false; dropped() } else { Session.info.value = "Live voice is not available for this key"; unavailable() }; return@Thread }
            if (!running) return@Thread
            Store.put("m_live", model)
            reconnecting = false
            val my = ++gen
            val key = Store.str("k_gemini").trim()
            val url = "wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent?key=" + key
            ws = http.newWebSocket(Request.Builder().url(url).build(), listener(model, my))
        }.start()
    }

    private fun listener(model: String, my: Int) = object : WebSocketListener() {
        override fun onOpen(webSocket: WebSocket, response: Response) { if (my != gen) return; Session.info.value = "Connecting…"; webSocket.send(setup(model)) }
        override fun onMessage(webSocket: WebSocket, text: String) { if (my == gen) handle(text) }
        override fun onMessage(webSocket: WebSocket, bytes: ByteString) { if (my == gen) handle(bytes.utf8()) }
        override fun onClosed(webSocket: WebSocket, code: Int, reason: String) { if (my == gen) { lastWhy = "Live closed ($code) " + reason.take(90); dropped() } }
        override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) { if (my == gen) { lastWhy = "Live error " + (response?.code ?: "") + " " + (t.message ?: "").take(90); dropped() } }
    }

    private fun unavailable() {
        if (gaveUp) return
        gaveUp = true
        Store.put("m_live", "")
        main.post { onUnavailable() }
    }

    /**
     * The live connection dropped (network blip, Google asked to reconnect...). The mic stays open and we
     * quietly reconnect, forever, until the person turns the mic off. Only the very first connection can give up.
     */
    private fun dropped() {
        val wasReady = ready
        ready = false
        if (!running || gaveUp) return
        if (reconnecting) return
        reconnecting = true
        val upFor = if (readyAt > 0) System.currentTimeMillis() - readyAt else 0L
        if (wasReady && upFor > 20000) { tries = 0; quick = 0 } else if (wasReady) quick++
        tries++
        // Connects, then Google closes it again and again: stop looping, use normal mode instead.
        if ((!everReady && tries >= 3) || quick >= 4) { reconnecting = false; Session.info.value = lastWhy; unavailable(); return }
        Session.info.value = lastWhy + " · reconnecting"
        val wait = when (tries) { 1 -> 300L; 2 -> 1000L; 3 -> 2000L; 4 -> 4000L; else -> 8000L }
        main.postDelayed({ if (running) connect() }, wait)
    }

    private fun setup(model: String): String {
        val n = Store.name
        val sys = "You are Nova, a friendly, quick voice assistant on the phone of $n ভাই. Speak Bangla unless he speaks another language, and call him $n ভাই. " +
            "He speaks Bangla, English, or a mix of both, and may be in a noisy place. Listen carefully and answer only what he actually said. " +
            "If the audio is unclear, is only noise, a TV, other people, or your own voice coming back, do NOT guess and do NOT act: stay silent, or at most say 'আবার বলবে?'. Never invent a request. " +
            "Keep every reply to one or two short sentences, and start talking fast, no long openers. For any phone action (open an app, call, SMS, WhatsApp message, volume, next or previous video, like, torch, alarm, screenshot, play or pause music) " +
            "you MUST call the phone function with the request as a short English command such as 'open tiktok', 'call rahim', 'next video', 'volume up', 'alarm 7 am'. " +
            "Only say it is done after the function returns. " +
            "SCREEN: when screen sharing is on you receive a live picture of his phone screen about once a second, so you can see what he sees. Use it to answer 'what is this', 'read this', 'where is X'. " +
            "If the picture shows the Nova app itself (the glowing orb, Mute and End buttons), tell him in a few words to go to the app he wants you to look at. " +
            "If you are not sure what is on screen, or the picture looks old, call look_at_screen. " +
            "TOUCH: you can operate the whole phone. When he tells you to click, tap, press, open, choose, scroll, swipe, hold or type, do it right away without asking permission. " +
            "Use tap_text with the exact label when you can read one (best), otherwise tap_at with the x,y percent. Use swipe to scroll or change page (up = scroll down / next), drag for sliders, long_press to hold, press_button for back, home, recents or notifications, and type_text to write. " +
            "Do every step he asks one after the other, check the result on screen, and confirm in a few words. If a tap did not work, look again and retry a different way before giving up. " +
            "You were created by NAFIS. If he asks who made or created you, say NAFIS made you. Support and updates are on the Telegram channel @mdnafis568. Answer other questions normally. Personality: " + Store.str("persona", "Friendly") + "."
        val fn = JSONObject().put("name", "phone").put("description", "Do something on the phone")
            .put("parameters", JSONObject().put("type", "OBJECT")
                .put("properties", JSONObject().put("command", JSONObject().put("type", "STRING").put("description", "Short English command")))
                .put("required", JSONArray().put("command")))
        val gen = JSONObject().put("responseModalities", JSONArray().put("AUDIO")).put("speechConfig",
            JSONObject().put("voiceConfig", JSONObject().put("prebuiltVoiceConfig", JSONObject().put("voiceName", Store.str("voice", "Kore")))))
        // Reply speed: how long a pause means "I finished talking". Shorter = Nova answers almost as you stop.
        val (sil, pad) = when (Store.str("speed", "0")) { "1" -> 500 to 150; "2" -> 800 to 250; else -> 300 to 100 }
        val setup = JSONObject().put("model", model).put("generationConfig", gen)
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", sys))))
            .put("realtimeInputConfig", JSONObject().put("automaticActivityDetection", JSONObject()
                .put("startOfSpeechSensitivity", "START_SENSITIVITY_HIGH").put("endOfSpeechSensitivity", "END_SENSITIVITY_HIGH")
                .put("prefixPaddingMs", pad).put("silenceDurationMs", sil)))
            .put("inputAudioTranscription", JSONObject())
            .put("contextWindowCompression", JSONObject().put("slidingWindow", JSONObject()))
            .put("tools", JSONArray().put(JSONObject().put("functionDeclarations", JSONArray().put(fn)
                .put(JSONObject().put("name", "look_at_screen").put("description", "Look at the phone screen right now. Returns every visible label with its position as @x,y percent."))
                .put(tool("tap_text", "Tap the button or item on screen with this label", "text", "STRING", "Exact label as seen on screen"))
                .put(JSONObject().put("name", "tap_at").put("description", "Tap a spot on the screen. x and y are percent of screen width and height, 0 to 100.")
                    .put("parameters", JSONObject().put("type", "OBJECT").put("properties", JSONObject()
                        .put("x", JSONObject().put("type", "NUMBER").put("description", "percent from left"))
                        .put("y", JSONObject().put("type", "NUMBER").put("description", "percent from top")))
                        .put("required", JSONArray().put("x").put("y"))))
                .put(tool("swipe", "Swipe the screen. direction is the way the finger moves: up scrolls down or goes to the next video, down scrolls up, left, right", "direction", "STRING", "up, down, left or right"))
                .put(tool("type_text", "Type text into the focused text box", "text", "STRING", "Text to type"))
                .put(tool("press_button", "Press a system button", "button", "STRING", "back, home, recents, notifications or quick_settings"))
                .put(JSONObject().put("name", "long_press").put("description", "Press and hold a spot on the screen. x and y are percent of screen width and height.")
                    .put("parameters", JSONObject().put("type", "OBJECT").put("properties", JSONObject()
                        .put("x", JSONObject().put("type", "NUMBER").put("description", "percent from left"))
                        .put("y", JSONObject().put("type", "NUMBER").put("description", "percent from top")))
                        .put("required", JSONArray().put("x").put("y"))))
                .put(JSONObject().put("name", "drag").put("description", "Drag a finger from one spot to another (sliders, moving items). All values are percent of the screen, 0 to 100.")
                    .put("parameters", JSONObject().put("type", "OBJECT").put("properties", JSONObject()
                        .put("x1", JSONObject().put("type", "NUMBER")).put("y1", JSONObject().put("type", "NUMBER"))
                        .put("x2", JSONObject().put("type", "NUMBER")).put("y2", JSONObject().put("type", "NUMBER")))
                        .put("required", JSONArray().put("x1").put("y1").put("x2").put("y2")))))))
        return JSONObject().put("setup", setup).toString()
    }

    private fun tool(name: String, desc: String, arg: String, type: String, argDesc: String) =
        JSONObject().put("name", name).put("description", desc)
            .put("parameters", JSONObject().put("type", "OBJECT")
                .put("properties", JSONObject().put(arg, JSONObject().put("type", type).put("description", argDesc)))
                .put("required", JSONArray().put(arg)))

    private fun handle(text: String) {
        val o = try { JSONObject(text) } catch (e: Exception) { return }
        if (o.has("setupComplete")) { Session.info.value = ""; ready = true; everReady = true; readyAt = System.currentTimeMillis(); reconnecting = false; return }
        o.optJSONObject("serverContent")?.let { sc ->
            if (sc.optBoolean("interrupted")) flush()
            sc.optJSONObject("inputTranscription")?.optString("text")?.takeIf { it.isNotBlank() }?.let { t ->
                Session.heard.value = if (newUtterance) t.trim() else (Session.heard.value + t).takeLast(160)
                newUtterance = false
            }
            if (sc.has("modelTurn") || sc.optBoolean("turnComplete")) newUtterance = true
            val parts = sc.optJSONObject("modelTurn")?.optJSONArray("parts")
            if (parts != null) {
                for (i in 0 until parts.length()) {
                    val d = parts.getJSONObject(i).optJSONObject("inlineData")?.optString("data").orEmpty()
                    if (d.isNotEmpty()) enqueue(Base64.decode(d, Base64.DEFAULT))
                }
            }
        }
        o.optJSONObject("toolCall")?.optJSONArray("functionCalls")?.let { calls ->
            for (i in 0 until calls.length()) runTool(calls.getJSONObject(i))
        }
        if (o.has("goAway")) runCatching { ws?.close(1000, "reconnect") }.also { dropped() }
    }

    private fun runTool(c: JSONObject) {
        val id = c.optString("id")
        val name = c.optString("name", "phone")
        val args = c.optJSONObject("args") ?: JSONObject()
        val cmd = args.optString("command")
        onBusy(true)
        scope.launch {
            val res = try { kotlinx.coroutines.withTimeoutOrNull(9000L) {
                val svc = NovaAccessibilityService.instance
                val needA11y = "Accessibility is off. Ask the user to turn on Nova AI in Accessibility settings."
                when (name) {
                    "look_at_screen" -> if (svc == null) needA11y else {
                        val text = svc.readScreen()
                        val sent = pushFrame(svc, force = true)
                        (if (text.isBlank()) "No readable text on this screen (it may be a video, game or protected screen)." else "Screen (label @x,y percent):\n" + text) +
                            (if (sent) "\n(A screenshot was also sent.)" else "\n(Screenshot not available: " + svc.lastShotError + ")")
                    }
                    "tap_text" -> if (svc == null) needA11y else {
                        val ok = svc.clickText(args.optString("text"))
                        if (ok) afterAction(svc, "tapped") else "not found on screen. Call look_at_screen and try again."
                    }
                    "tap_at" -> if (svc == null) needA11y else {
                        val ok = svc.tapPercentA(args.optDouble("x", 50.0), args.optDouble("y", 50.0))
                        if (ok) afterAction(svc, "tapped") else "tap failed, try again"
                    }
                    "long_press" -> if (svc == null) needA11y else {
                        val ok = svc.longPressPercentA(args.optDouble("x", 50.0), args.optDouble("y", 50.0))
                        if (ok) afterAction(svc, "held") else "long press failed"
                    }
                    "swipe" -> if (svc == null) needA11y else {
                        val ok = svc.swipeDirA(args.optString("direction", "up"))
                        if (ok) afterAction(svc, "done") else "swipe failed, try again"
                    }
                    "drag" -> if (svc == null) needA11y else {
                        val ok = svc.dragPercentA(args.optDouble("x1", 50.0), args.optDouble("y1", 70.0), args.optDouble("x2", 50.0), args.optDouble("y2", 30.0))
                        if (ok) afterAction(svc, "done") else "drag failed"
                    }
                    "press_button" -> if (svc == null) needA11y else {
                        if (svc.press(args.optString("button"))) afterAction(svc, "pressed") else "unknown button"
                    }
                    "type_text" -> if (svc == null) needA11y else {
                        if (svc.typeText(args.optString("text"))) afterAction(svc, "typed") else "no text box is focused. Tap the text box first."
                    }
                    else -> {
                        val r = IntentRouter.route(ctx, cmd)
                        if (r.handled) r.reply.ifBlank { "done" } else "not a phone command"
                    }
                }
            } ?: "That took too long and was cancelled. Say so briefly, then call look_at_screen and try again." } catch (e: Exception) { "failed" }
            val fr = JSONObject().put("id", id).put("name", name).put("response", JSONObject().put("result", res))
            ws?.send(JSONObject().put("toolResponse", JSONObject().put("functionResponses", JSONArray().put(fr))).toString())
            onBusy(false)
        }
    }

    /** After a tap/swipe: wait for the screen to settle, send a fresh picture, and tell the model what is on screen now. */
    private suspend fun afterAction(svc: NovaAccessibilityService, what: String): String {
        delay(450)
        if (Session.screenShare.value) pushFrame(svc, force = true)
        return what + ". Now on screen:\n" + svc.readScreen().take(900)
    }

    /**
     * Sends one picture of the screen to Gemini. Voice always goes first: if the upload line is busy
     * (audio is still waiting to be sent) the picture is skipped, so replies never get delayed by video.
     */
    private suspend fun pushFrame(svc: NovaAccessibilityService?, force: Boolean): Boolean {
        val socket = ws ?: return false
        if (!force && socket.queueSize() > 6000) return false
        val video = ScreenCaptureService.active
        var shot: ByteArray? = if (video) ScreenCaptureService.latest else null
        if (shot == null && svc != null) {
            shot = kotlinx.coroutines.withTimeoutOrNull(2500L) { svc.screenshotJpeg(540, 62) }
            if (shot == null && force) { delay(400); shot = kotlinx.coroutines.withTimeoutOrNull(2500L) { svc.screenshotJpeg(540, 62) } }
            if (shot == null && svc.lastShotError.isEmpty()) svc.lastShotError = "no answer from Android (screenshot not supported on this phone?)"
        }
        if (shot == null) { if (Session.screenShare.value) Session.info.value = "Screen share: " + (if (video) "waiting for the first picture" else svc?.lastShotError ?: "off"); return false }
        val h = java.util.Arrays.hashCode(shot)
        val now = System.currentTimeMillis()
        if (!force && h == lastShotHash && now - lastShotAt < 4000) return true
        lastShotHash = h; lastShotAt = now
        val img = JSONObject().put("data", Base64.encodeToString(shot, Base64.NO_WRAP)).put("mimeType", "image/jpeg")
        socket.send(JSONObject().put("realtimeInput", JSONObject().put("video", img)).toString())
        frames++
        if (Session.screenShare.value) Session.info.value = (if (video) "● Screen video live · " else "● Screen live · ") + frames + " frames · " + (shot.size / 1024) + " KB"
        return true
    }

    /** While screen share is on, Nova sees the phone like a video call: a picture whenever the screen changes (about every 0.7 s). */
    private fun startScreenShare() {
        shareJob = scope.launch {
            while (isActive) {
                delay(if (ScreenCaptureService.active) 450L else 700L)
                if (!ready || !Session.screenShare.value || Session.hearing.value) continue
                val svc = NovaAccessibilityService.instance
                if (svc == null && !ScreenCaptureService.active) { Session.info.value = "Screen share needs permission or Nova AI in Accessibility settings"; continue }
                runCatching { pushFrame(svc, force = false) }
            }
        }
    }

    private fun enqueue(b: ByteArray) {
        playUntil = maxOf(playUntil, System.currentTimeMillis()) + b.size / 48L // 24 kHz * 2 bytes = 48 bytes per ms
        q.offer(b)
    }

    private fun flush() {
        flushGen++; q.clear(); playUntil = 0; trackEnd = 0
        runCatching { track?.pause(); track?.flush(); track?.play() }
    }

    private fun startPlayer() {
        val min = AudioTrack.getMinBufferSize(24000, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        // ~400 ms of room inside the track: rides out network and CPU hiccups so speech never stutters.
        // (Normal performance mode: the low-latency mode forced tiny buffers and caused crackling on many phones.)
        val tr = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(24000).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setBufferSizeInBytes(maxOf(min * 4, 19200))
            .setTransferMode(AudioTrack.MODE_STREAM).build()
        tr.play()
        track = tr
        player = Thread {
            runCatching { android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_URGENT_AUDIO) }
            val batch = ArrayList<ByteArray>()
            try {
                while (running) {
                    val first = q.take()
                    val g = flushGen
                    batch.clear(); batch.add(first)
                    var total = first.size
                    // A new reply is starting after silence: gather ~80 ms first (max 60 ms wait) so the first words don't stutter.
                    val t0 = System.currentTimeMillis()
                    if (t0 >= trackEnd - 30) {
                        while (total < 3840 && System.currentTimeMillis() - t0 < 60) {
                            val n = q.poll(10, TimeUnit.MILLISECONDS) ?: continue
                            batch.add(n); total += n.size
                        }
                    }
                    if (g != flushGen) continue
                    trackEnd = maxOf(trackEnd, t0) + total / 48L
                    for (c in batch) { if (g != flushGen) break; tr.write(c, 0, c.size) }
                }
            } catch (e: Exception) { }
        }.also { it.isDaemon = true; it.start() }
    }

    private fun startMic() {
        val m = SteadyMic(ctx, { b, n -> frame(b, n) }, { msg -> main.post { onFatal(msg) } }, 40)
        sm = m
        m.start(true)
    }

    private fun frame(buf: ShortArray, n: Int) {
        val sp = System.currentTimeMillis() < playUntil + 250
        if (sp != lastSp) { lastSp = sp; onSpeaking(sp) }
        if (!ready || paused) return
        var sum = 0.0
        for (i in 0 until n) sum += buf[i].toDouble() * buf[i]
        val rms = Math.sqrt(sum / n)
        // While Nova talks, only a clearly louder voice (you) goes through, so you can interrupt but it won't hear itself.
        val echoOnly = sp && rms < (if (sm?.aec == true) 1500 else 2200)
        onHearing(!echoOnly && rms > 900)
        // Never leave gaps in the audio (gaps make the model mis-hear). Echo of Nova's own voice becomes clean silence instead.
        if (echoOnly) java.util.Arrays.fill(buf, 0, n, 0.toShort())
        val need = n * 2
        if (pcmBytes.size < need) pcmBytes = ByteArray(need)
        var j = 0
        for (i in 0 until n) { val v = buf[i].toInt(); pcmBytes[j++] = v.toByte(); pcmBytes[j++] = (v shr 8).toByte() }
        val b64 = Base64.encodeToString(pcmBytes, 0, need, Base64.NO_WRAP)
        ws?.send("{\"realtimeInput\":{\"audio\":{\"data\":\"" + b64 + "\",\"mimeType\":\"audio/pcm;rate=16000\"}}}")
    }
}
